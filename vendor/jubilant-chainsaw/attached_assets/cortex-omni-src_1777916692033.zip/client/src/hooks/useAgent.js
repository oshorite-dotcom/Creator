import { useAppStore } from '../store/appStore'

const BASE = '/api'

export function useAgent() {
  const store = useAppStore()

  async function login(role, name = 'Learner', tier = 'free') {
    try {
      const res = await fetch(`${BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role, name, tier }),
      })
      const data = await res.json()
      store.login(data.user)
    } catch {
      store.setError('Login failed')
    }
  }

  async function devLogin(key, name = 'Developer') {
    try {
      const res = await fetch(`${BASE}/auth/dev-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, name }),
      })
      if (!res.ok) return false
      const data = await res.json()
      store.login(data.user)
      return true
    } catch {
      return false
    }
  }

  async function uploadFile(file) {
    const s = useAppStore.getState()
    if (!s.entitlements?.can_use_pdf) {
      store.setUpgradeModal(true)
      return
    }
    try {
      const form = new FormData()
      form.append('file', file)
      const res = await fetch(`${BASE}/ingest`, { method: 'POST', body: form })
      const data = await res.json()
      store.setContext(data.context || '')
    } catch {
      store.setError('File upload failed')
    }
  }

  async function invoke(query) {
    store.setLoading(true)
    store.setError(null)
    store.setLastQuery(query)
    try {
      const s = useAppStore.getState()
      const res = await fetch(`${BASE}/invoke`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_input: query,
          ...s.params,
          processed_context: s.context,
          role: s.role,
          tier: s.tier,
          user_id: s.user?.name || 'guest',
        }),
      })
      const data = await res.json()
      if (data.limit_reached) {
        store.setError('Daily query limit reached. Upgrade to Pro for unlimited queries.')
        store.setUpgradeModal(true)
        store.setLoading(false)
        return
      }
      store.setAgentResult(data)
    } catch {
      store.setError('Agent invocation failed')
      store.setLoading(false)
    }
  }

  async function fetchPractice() {
    const s = useAppStore.getState()
    if (!s.entitlements?.can_use_practice) {
      store.setUpgradeModal(true)
      return
    }
    const res = await fetch(`${BASE}/practice`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        context: s.agentResult?.final_output || '',
        target_exam: s.params.target_exam,
        model: s.params.model,
        language: s.params.language,
      }),
    })
    const data = await res.json()
    store.setPractice(data.output)
  }

  async function fetchDiagnostic(studentAnswer, topic = '') {
    const s = useAppStore.getState()
    if (!s.entitlements?.can_view_diagnostics) {
      store.setUpgradeModal(true)
      return null
    }
    const res = await fetch(`${BASE}/diagnose`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        student_answer: studentAnswer,
        reference: s.agentResult?.final_output || '',
        target_exam: s.params.target_exam,
        model: s.params.model,
        language: s.params.language,
        user_id: s.user?.name || 'guest',
        topic: topic || s.lastQuery.slice(0, 80) || s.params.target_exam,
        role: s.role,
        tier: s.tier,
      }),
    })
    const data = await res.json()
    store.setDiagnostic(data.output)
    return data
  }

  async function addToRevision(topic, difficulty = 'medium') {
    const s = useAppStore.getState()
    await fetch(`${BASE}/revision`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_id: s.user?.name || 'guest',
        topic,
        exam: s.params.target_exam,
        difficulty,
      }),
    })
  }

  return { login, devLogin, uploadFile, invoke, fetchPractice, fetchDiagnostic, addToRevision }
}
