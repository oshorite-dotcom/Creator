import { create } from 'zustand'

export const useAppStore = create((set, get) => ({
  phase: 'auth',

  user: null,
  role: null,
  tier: 'free',
  entitlements: {},
  upgradeModal: false,

  params: {
    target_exam: 'JEE',
    pedagogy_style: 'Standard',
    language: 'English',
    model: 'gemini-2.5-flash',
  },

  context: '',
  lastQuery: '',
  agentResult: null,
  practiceOutput: null,
  diagnosticOutput: null,
  loading: false,
  error: null,

  setPhase: (phase) => set({ phase }),

  login: (user) => set({
    user,
    role: user.role,
    tier: user.tier,
    entitlements: user.entitlements,
    phase: 'params',
  }),

  setParam: (key, value) => set((s) => ({
    params: { ...s.params, [key]: value },
  })),

  setContext: (ctx) => set({ context: ctx }),
  setLastQuery: (q) => set({ lastQuery: q }),

  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
  setUpgradeModal: (open) => set({ upgradeModal: open }),

  setAgentResult: (result) => set({
    agentResult: result,
    practiceOutput: null,
    diagnosticOutput: null,
    phase: 'tutor',
    loading: false,
  }),

  setPractice: (output) => set({ practiceOutput: output }),
  setDiagnostic: (output) => set({ diagnosticOutput: output }),

  reset: () => set({
    agentResult: null,
    practiceOutput: null,
    diagnosticOutput: null,
    context: '',
    error: null,
    phase: 'agent',
  }),
}))
