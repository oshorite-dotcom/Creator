import { useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import PulsingSphere from '../three/PulsingSphere'
import { useAgent } from '../hooks/useAgent'
import { useAppStore } from '../store/appStore'

function ProBadge({ label }) {
  return (
    <span className="inline-flex items-center gap-1 text-xs font-mono px-1.5 py-0.5
                     rounded bg-accent/15 text-accent border border-accent/25">
      ✦ {label}
    </span>
  )
}

export default function AgentInit() {
  const { invoke, uploadFile } = useAgent()
  const { params, loading, error, entitlements, tier, setUpgradeModal } = useAppStore()
  const [query, setQuery] = useState('')
  const [fileName, setFileName] = useState(null)
  const [localLoading, setLocalLoading] = useState(false)
  const fileRef = useRef()

  async function handleFile(e) {
    const f = e.target.files?.[0]
    if (!f) return
    setFileName(f.name)
    await uploadFile(f)
  }

  async function handleInvoke() {
    if (!query.trim()) return
    setLocalLoading(true)
    await invoke(query)
    setLocalLoading(false)
  }

  const isLoading = loading || localLoading
  const canPDF = entitlements?.can_use_pdf
  const queryLimit = entitlements?.query_limit

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      <AnimatePresence mode="wait">
        {isLoading ? (
          <motion.div
            key="sphere"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.4 }}
            transition={{ duration: 0.5, type: 'spring' }}
            className="flex flex-col items-center gap-6"
          >
            <div className="w-48 h-48">
              <PulsingSphere />
            </div>
            <motion.div
              animate={{ opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-center"
            >
              <p className="text-accent font-mono text-sm">Compiling Agentic Graph...</p>
              <p className="text-muted text-xs mt-1">Routing through LangGraph · {params.model}</p>
            </motion.div>
          </motion.div>
        ) : (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -24 }}
            transition={{ duration: 0.4 }}
            className="w-full max-w-xl space-y-4"
          >
            <div className="text-center mb-6">
              <p className="tag mb-2">AGENT INITIALIZATION</p>
              <h2 className="text-2xl font-bold text-text">What would you like to learn?</h2>
              <div className="flex gap-2 justify-center mt-2 flex-wrap">
                <span className="tag">{params.target_exam}</span>
                <span className="tag">{params.pedagogy_style}</span>
                <span className="tag">{params.language}</span>
                <span className={`tag ${tier === 'pro' ? 'text-accent border-accent/40' : ''}`}>
                  {tier === 'pro' ? '✦ ' : ''}{params.model}
                </span>
                {queryLimit > 0 && (
                  <span className="tag text-yellow-500 border-yellow-800">
                    {queryLimit} queries/day
                  </span>
                )}
              </div>
            </div>

            <div className="glass p-5 space-y-4">
              <textarea
                rows={4}
                value={query}
                onChange={e => setQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && e.ctrlKey && handleInvoke()}
                placeholder="Ask anything related to your exam or subject..."
                className="w-full bg-transparent text-text placeholder-muted text-sm
                           outline-none resize-none font-sans leading-relaxed"
              />
              <div className="flex items-center gap-3 pt-2 border-t border-border">
                {canPDF ? (
                  <>
                    <input ref={fileRef} type="file" accept=".pdf,.txt,.png" onChange={handleFile} className="hidden" />
                    <button
                      onClick={() => fileRef.current?.click()}
                      className="btn-ghost flex items-center gap-2"
                    >
                      <span>📎</span>
                      <span>{fileName ? fileName.slice(0, 20) + '…' : 'Attach context'}</span>
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setUpgradeModal(true)}
                    className="flex items-center gap-2 text-muted text-sm px-3 py-1.5 rounded-lg
                               border border-dashed border-border hover:border-accent/40
                               hover:text-accent transition-all group"
                  >
                    <span>📎</span>
                    <span>Attach context</span>
                    <ProBadge label="Pro" />
                  </button>
                )}

                <button
                  onClick={handleInvoke}
                  disabled={!query.trim()}
                  className="btn-primary ml-auto px-8 disabled:opacity-40"
                >
                  Launch →
                </button>
              </div>
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="glass p-3 text-red-400 text-sm border border-red-500/20"
              >
                {error}
              </motion.div>
            )}

            {tier === 'free' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="glass p-3 flex items-center justify-between"
              >
                <p className="text-xs text-muted">
                  Free plan · PDF upload, diagnostics & more locked
                </p>
                <button
                  onClick={() => setUpgradeModal(true)}
                  className="text-xs font-mono text-accent hover:text-glow transition-colors whitespace-nowrap"
                >
                  View Pro →
                </button>
              </motion.div>
            )}

            <p className="text-center text-xs text-muted font-mono">
              Ctrl+Enter to submit · Powered by {params.model} via LangGraph
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
