import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import IsoNodeCluster from '../three/IsoNodeCluster'
import { useAgent } from '../hooks/useAgent'

const ROLE_META = {
  student:  { emoji: '🎓', desc: 'Adaptive tutoring, practice & diagnostics' },
  educator: { emoji: '📚', desc: 'Full access — create, diagnose, monitor' },
  parent:   { emoji: '👨‍👩‍👧', desc: 'Progress tracking & insights dashboard' },
}

const TIER_DATA = {
  free: {
    label: 'Free',
    price: '₹0',
    color: 'border-border',
    activeColor: 'border-border bg-white/5',
    tag: 'text-muted',
    features: [
      { text: '5 queries / day',         ok: true },
      { text: 'Practice questions',       ok: true },
      { text: 'English only',             ok: true },
      { text: 'PDF / image upload',       ok: false },
      { text: 'Diagnostic engine',        ok: false },
      { text: 'Hindi & Hinglish',         ok: false },
      { text: 'Advanced AI models',       ok: false },
      { text: 'Session dashboard',        ok: false },
      { text: 'Multi-model compare',      ok: false },
      { text: 'Export & custom prompts',  ok: false },
    ],
  },
  pro: {
    label: 'Pro',
    price: '₹299',
    color: 'border-accent/30',
    activeColor: 'border-accent bg-accent/10 shadow-glow',
    tag: 'text-accent',
    features: [
      { text: 'Unlimited queries',        ok: true },
      { text: 'Practice questions',       ok: true },
      { text: 'PDF & image upload',       ok: true },
      { text: 'Diagnostic + mastery',     ok: true },
      { text: 'Hindi & Hinglish',         ok: true },
      { text: 'Gemini 1.5 Pro model',     ok: true },
      { text: 'Abstract pedagogy',        ok: true },
      { text: 'Session dashboard',        ok: true },
      { text: 'Multi-model compare',      ok: false },
      { text: 'Export & custom prompts',  ok: false },
    ],
  },
  pro_plus: {
    label: 'Pro Plus',
    price: '₹599',
    color: 'border-purple-500/30',
    activeColor: 'border-purple-400 bg-purple-500/10 shadow-[0_0_24px_rgba(168,85,247,0.25)]',
    tag: 'text-purple-400',
    features: [
      { text: 'Unlimited queries',        ok: true },
      { text: 'Practice questions',       ok: true },
      { text: 'PDF & image upload',       ok: true },
      { text: 'Diagnostic + mastery',     ok: true },
      { text: 'Hindi & Hinglish',         ok: true },
      { text: 'Gemini 1.5 Pro model',     ok: true },
      { text: 'Abstract pedagogy',        ok: true },
      { text: 'Session dashboard',        ok: true },
      { text: 'Multi-model compare',      ok: true },
      { text: 'Export & custom prompts',  ok: true },
    ],
  },
}

function TierCard({ tier, selected, onSelect }) {
  const d = TIER_DATA[tier]
  const isPro = tier === 'pro'
  const isPlus = tier === 'pro_plus'

  return (
    <motion.button
      onClick={() => onSelect(tier)}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`flex-1 min-w-[140px] rounded-xl p-3.5 text-left border transition-all duration-200
        ${selected ? d.activeColor : `${d.color} bg-surface hover:brightness-110`}`}
    >
      <div className="flex items-start justify-between mb-2.5">
        <div>
          <span className={`text-xs font-mono font-bold uppercase tracking-widest ${d.tag}`}>
            {isPlus ? '★ ' : isPro ? '✦ ' : ''}{d.label}
          </span>
          <p className="text-base font-bold text-text mt-0.5">{d.price}<span className="text-muted text-xs font-normal">/mo</span></p>
        </div>
        {selected && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className={`w-4 h-4 rounded-full flex items-center justify-center text-xs font-bold
              ${isPlus ? 'bg-purple-500' : isPro ? 'bg-accent' : 'bg-border'} text-white`}
          >
            ✓
          </motion.div>
        )}
      </div>
      <ul className="space-y-0.5">
        {d.features.map((f, i) => (
          <li key={i} className={`text-xs font-mono ${f.ok ? 'text-text/80' : 'text-muted/35 line-through'}`}>
            {f.ok ? '✓' : '✗'} {f.text}
          </li>
        ))}
      </ul>
    </motion.button>
  )
}

export default function AuthGateway() {
  const { login, devLogin } = useAgent()
  const [selected, setSelected] = useState(null)
  const [tier, setTier] = useState('free')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [showDev, setShowDev] = useState(false)
  const [devKey, setDevKey] = useState('')
  const [devError, setDevError] = useState('')
  const [devLoading, setDevLoading] = useState(false)

  async function handleEnter() {
    if (!selected) return
    setLoading(true)
    await login(selected, name || 'Learner', tier)
    setLoading(false)
  }

  async function handleDevLogin() {
    if (!devKey.trim()) return
    setDevLoading(true)
    setDevError('')
    const ok = await devLogin(devKey.trim(), name || 'Developer')
    if (!ok) setDevError('Invalid bypass key. Access denied.')
    setDevLoading(false)
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-radial from-accent/5 via-transparent to-transparent pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: -24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="text-center mb-6 z-10"
      >
        <p className="tag mb-3">BUILD 2.2.0 · SPATIAL AI</p>
        <h1 className="text-5xl font-bold text-text tracking-tight">
          CORTEX <span className="text-accent">OMNI</span>
        </h1>
        <p className="text-muted mt-2 text-sm font-mono">
          Adaptive · Multi-Modal · Exam-Native Learning Engine
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="w-full max-w-xl h-64 z-10"
      >
        <IsoNodeCluster onSelect={setSelected} selected={selected} />
      </motion.div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="text-muted text-sm font-mono mb-6 z-10"
      >
        Select your role node to continue
      </motion.p>

      <AnimatePresence>
        {selected && (
          <motion.div
            key="role-confirm"
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 300, damping: 24 }}
            className="glass p-6 w-full max-w-2xl z-10 space-y-5"
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl">{ROLE_META[selected]?.emoji}</span>
              <div>
                <p className="font-semibold capitalize text-text">{selected}</p>
                <p className="text-xs text-muted">{ROLE_META[selected]?.desc}</p>
              </div>
            </div>

            <input
              className="w-full bg-surface border border-border rounded-xl px-4 py-2.5
                         text-sm text-text placeholder-muted outline-none
                         focus:border-accent/60 transition-colors"
              placeholder="Your name (optional)"
              value={name}
              onChange={e => setName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleEnter()}
            />

            <div>
              <p className="text-xs font-mono text-muted uppercase tracking-widest mb-2">Select Plan</p>
              <div className="flex gap-2 overflow-x-auto pb-1">
                {['free', 'pro', 'pro_plus'].map(t => (
                  <TierCard key={t} tier={t} selected={tier === t} onSelect={setTier} />
                ))}
              </div>
            </div>

            <button
              onClick={handleEnter}
              disabled={loading}
              className={`w-full py-3 rounded-xl font-semibold text-sm transition-all disabled:opacity-50
                ${tier === 'pro_plus'
                  ? 'bg-gradient-to-r from-purple-600 to-accent text-white shadow-[0_0_20px_rgba(168,85,247,0.4)]'
                  : tier === 'pro'
                    ? 'btn-primary shadow-glow'
                    : 'btn-ghost border-border'}`}
            >
              {loading
                ? 'Initializing...'
                : tier === 'pro_plus'
                  ? '★ Enter Cortex Pro Plus →'
                  : tier === 'pro'
                    ? '✦ Enter Cortex Pro →'
                    : 'Enter Free →'}
            </button>

            {/* Developer Access Bypass */}
            <div className="border-t border-border/40 pt-3">
              <button
                onClick={() => { setShowDev(v => !v); setDevError('') }}
                className="w-full text-xs font-mono text-muted/50 hover:text-muted transition-colors flex items-center justify-center gap-2"
              >
                <span>🔑</span>
                <span>Developer Access</span>
                <span className={`transition-transform ${showDev ? 'rotate-180' : ''}`}>▾</span>
              </button>

              <AnimatePresence>
                {showDev && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="pt-3 space-y-2">
                      <div className="flex gap-2">
                        <input
                          type="password"
                          value={devKey}
                          onChange={e => setDevKey(e.target.value)}
                          onKeyDown={e => e.key === 'Enter' && handleDevLogin()}
                          placeholder="Enter bypass key..."
                          className="flex-1 bg-surface border border-border rounded-lg px-3 py-2
                                     text-sm text-text placeholder-muted outline-none
                                     focus:border-orange-500/60 transition-colors font-mono"
                        />
                        <button
                          onClick={handleDevLogin}
                          disabled={devLoading || !devKey.trim()}
                          className="px-4 py-2 rounded-lg text-sm font-mono font-bold
                                     bg-orange-500/20 border border-orange-500/40 text-orange-400
                                     hover:bg-orange-500/30 transition-all disabled:opacity-40"
                        >
                          {devLoading ? '...' : 'Unlock →'}
                        </button>
                      </div>
                      {devError && (
                        <p className="text-xs text-red-400 font-mono">{devError}</p>
                      )}
                      <p className="text-xs text-muted/40 font-mono text-center">
                        Owner-only · All entitlements · No rate limits
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-0">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-px h-px rounded-full bg-accent/30"
            style={{ left: `${Math.random() * 100}%`, top: `${Math.random() * 100}%` }}
            animate={{ opacity: [0, 0.6, 0], scale: [0, 3, 0] }}
            transition={{ duration: 3 + Math.random() * 4, repeat: Infinity, delay: Math.random() * 5 }}
          />
        ))}
      </div>
    </div>
  )
}
