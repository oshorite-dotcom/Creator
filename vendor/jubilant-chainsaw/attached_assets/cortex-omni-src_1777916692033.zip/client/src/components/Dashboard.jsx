import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore } from '../store/appStore'

const API = '/api'

function ScoreBar({ score }) {
  const pct = Math.round(score * 10)
  const color = score >= 7 ? '#10b981' : score >= 4 ? '#f59e0b' : '#ef4444'
  return (
    <div className="flex items-center gap-2 flex-1">
      <div className="flex-1 h-1.5 bg-border rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="h-full rounded-full"
          style={{ background: color }}
        />
      </div>
      <span className="text-xs font-mono w-8 text-right" style={{ color }}>
        {score.toFixed(1)}
      </span>
    </div>
  )
}

function MasteryPanel({ userId }) {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!userId) return
    fetch(`${API}/mastery/${encodeURIComponent(userId)}`)
      .then(r => r.json())
      .then(d => { setData(d.mastery || []); setLoading(false) })
      .catch(() => setLoading(false))
  }, [userId])

  return (
    <div className="glass p-5 space-y-3">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs font-mono text-muted uppercase tracking-widest">Mastery Scores</p>
        <span className="tag">{data.length} topics</span>
      </div>
      {loading ? (
        <p className="text-muted text-xs">Loading...</p>
      ) : data.length === 0 ? (
        <p className="text-muted text-xs italic">
          No mastery data yet — run a diagnostic to begin tracking.
        </p>
      ) : (
        <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
          {data.map((m, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.04 }}
              className="flex items-center gap-3"
            >
              <div className="min-w-0 flex-1">
                <p className="text-xs text-text truncate">{m.topic}</p>
                <p className="text-xs text-muted font-mono">{m.exam} · {m.attempts}x</p>
              </div>
              <ScoreBar score={m.score} />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}

function RevisionPanel({ userId }) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)

  async function load() {
    if (!userId) return
    const r = await fetch(`${API}/revision/${encodeURIComponent(userId)}`)
    const d = await r.json()
    setItems(d.queue || [])
    setLoading(false)
  }

  useEffect(() => { load() }, [userId])

  async function dismiss(id) {
    await fetch(`${API}/revision/${id}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId }),
    })
    setItems(prev => prev.filter(it => it.id !== id))
  }

  const diffColor = { easy: '#10b981', medium: '#f59e0b', hard: '#ef4444' }

  return (
    <div className="glass p-5 space-y-3">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs font-mono text-muted uppercase tracking-widest">Revision Queue</p>
        <span className="tag">{items.length} pending</span>
      </div>
      {loading ? (
        <p className="text-muted text-xs">Loading...</p>
      ) : items.length === 0 ? (
        <p className="text-muted text-xs italic">
          Queue is clear — topics flagged for revision will appear here.
        </p>
      ) : (
        <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
          <AnimatePresence>
            {items.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.25, delay: i * 0.03 }}
                className="flex items-center justify-between gap-3 py-1.5 border-b border-border last:border-0"
              >
                <div className="min-w-0">
                  <p className="text-xs text-text truncate">{item.topic}</p>
                  <p className="text-xs text-muted font-mono">{item.exam}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span
                    className="tag"
                    style={{ color: diffColor[item.difficulty] || '#6b7280', borderColor: diffColor[item.difficulty] || '#1e2d45' }}
                  >
                    {item.difficulty}
                  </span>
                  <button
                    onClick={() => dismiss(item.id)}
                    className="text-muted hover:text-red-400 transition-colors text-xs"
                    title="Mark done"
                  >
                    ✓
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  )
}

function HistoryPanel({ userId, onReplay }) {
  const [sessions, setSessions] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!userId) return
    fetch(`${API}/sessions/${encodeURIComponent(userId)}`)
      .then(r => r.json())
      .then(d => { setSessions(d.sessions || []); setLoading(false) })
      .catch(() => setLoading(false))
  }, [userId])

  return (
    <div className="glass p-5 space-y-3">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs font-mono text-muted uppercase tracking-widest">Session History</p>
        <span className="tag">{sessions.length} sessions</span>
      </div>
      {loading ? (
        <p className="text-muted text-xs">Loading...</p>
      ) : sessions.length === 0 ? (
        <p className="text-muted text-xs italic">
          No sessions yet — your tutoring history will appear here.
        </p>
      ) : (
        <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
          {sessions.map((s, i) => (
            <motion.div
              key={s.id}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              className="p-3 rounded-xl bg-surface border border-border hover:border-accent/30
                         transition-all cursor-pointer group"
              onClick={() => onReplay && onReplay(s.query)}
            >
              <div className="flex items-start justify-between gap-2 mb-1">
                <span className="tag">{s.exam}</span>
                <span className="text-xs text-muted font-mono shrink-0">
                  {new Date(s.created_at).toLocaleDateString('en-IN', {
                    day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
                  })}
                </span>
              </div>
              <p className="text-xs text-text line-clamp-1 group-hover:text-accent transition-colors">
                {s.query}
              </p>
              <p className="text-xs text-muted mt-1 line-clamp-2 leading-relaxed">
                {s.preview}…
              </p>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}

export default function Dashboard({ onReplay }) {
  const { user } = useAppStore()
  const userId = user?.name || 'guest'

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <p className="text-xs font-mono text-muted uppercase tracking-widest">Learning Dashboard</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <MasteryPanel userId={userId} />
        <RevisionPanel userId={userId} />
      </div>
      <HistoryPanel userId={userId} onReplay={onReplay} />
    </div>
  )
}
