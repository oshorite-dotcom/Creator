import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import ReactMarkdown from 'react-markdown'
import { useAppStore } from '../store/appStore'
import { useAgent } from '../hooks/useAgent'

function MarkdownBlock({ content }) {
  return (
    <div className="prose-dark text-sm leading-relaxed">
      <ReactMarkdown>{content}</ReactMarkdown>
    </div>
  )
}

function Panel({ title, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="glass overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-5 py-4 hover:bg-white/5 transition-colors"
      >
        <span className="font-semibold text-sm text-text">{title}</span>
        <motion.span animate={{ rotate: open ? 90 : 0 }} transition={{ duration: 0.2 }}
          className="text-muted text-lg">›</motion.span>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="px-5 pb-5 border-t border-border"
          >
            <div className="pt-4">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default function TutorInterface() {
  const { agentResult, practiceOutput, diagnosticOutput, entitlements, reset, lastQuery, params, user } = useAppStore()
  const { fetchPractice, fetchDiagnostic, addToRevision } = useAgent()
  const [diagAnswer, setDiagAnswer] = useState('')
  const [practiceLoading, setPracticeLoading] = useState(false)
  const [diagLoading, setDiagLoading] = useState(false)
  const [diagScore, setDiagScore] = useState(null)
  const [revisionAdded, setRevisionAdded] = useState(false)
  const [savedIndicator, setSavedIndicator] = useState(!!agentResult?.session_id)

  async function handlePractice() {
    setPracticeLoading(true)
    await fetchPractice()
    setPracticeLoading(false)
  }

  async function handleDiagnose() {
    if (!diagAnswer.trim()) return
    setDiagLoading(true)
    const data = await fetchDiagnostic(diagAnswer)
    if (data?.score !== null && data?.score !== undefined) {
      setDiagScore(data.score)
    }
    setDiagLoading(false)
  }

  async function handleAddRevision() {
    const topic = lastQuery.slice(0, 80) || params.target_exam
    await addToRevision(topic, diagScore !== null && diagScore < 3 ? 'hard' : 'medium')
    setRevisionAdded(true)
  }

  return (
    <div className="min-h-screen px-4 py-10 max-w-3xl mx-auto space-y-4">
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between mb-2"
      >
        <div>
          <p className="tag mb-1">TUTOR RESPONSE</p>
          <h2 className="text-xl font-bold text-text">Cortex Omni · Analysis</h2>
        </div>
        <div className="flex items-center gap-2">
          {savedIndicator && (
            <motion.span
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="tag text-green-400 border-green-800"
            >
              ✓ Saved
            </motion.span>
          )}
          <button onClick={reset} className="btn-ghost">← New Query</button>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass p-6"
      >
        <MarkdownBlock content={agentResult?.final_output || ''} />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="grid grid-cols-2 gap-3"
      >
        <button
          onClick={handlePractice}
          disabled={practiceLoading}
          className="glass glass-hover px-4 py-4 text-left disabled:opacity-50 transition-all"
        >
          <p className="text-accent text-lg mb-1">🎯</p>
          <p className="font-semibold text-sm text-text">Practice Questions</p>
          <p className="text-xs text-muted mt-1">
            {practiceLoading ? 'Generating...' : 'Generate exam-style problems'}
          </p>
        </button>

        {entitlements?.can_view_diagnostics !== false ? (
          <button
            onClick={() => useAppStore.setState({ diagnosticOutput: '' })}
            className="glass glass-hover px-4 py-4 text-left transition-all"
          >
            <p className="text-accent text-lg mb-1">🔍</p>
            <p className="font-semibold text-sm text-text">Diagnose My Answer</p>
            <p className="text-xs text-muted mt-1">Trace-back error analysis</p>
          </button>
        ) : (
          <div className="glass px-4 py-4 opacity-40 cursor-not-allowed">
            <p className="text-lg mb-1">🔒</p>
            <p className="font-semibold text-sm text-text">Diagnostics</p>
            <p className="text-xs text-muted mt-1">Pro plan required</p>
          </div>
        )}
      </motion.div>

      <AnimatePresence>
        {practiceOutput && (
          <motion.div key="practice" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <Panel title="🎯 Practice Questions" defaultOpen>
              <MarkdownBlock content={practiceOutput} />
            </Panel>
          </motion.div>
        )}

        {diagnosticOutput !== null && (
          <motion.div key="diagnostic" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <Panel title="🔍 Diagnostic Engine — Trace-Back" defaultOpen>
              <textarea
                rows={4}
                value={diagAnswer}
                onChange={e => setDiagAnswer(e.target.value)}
                placeholder="Write your answer or solution process here..."
                className="w-full bg-surface border border-border rounded-xl px-4 py-3
                           text-sm text-text placeholder-muted outline-none
                           focus:border-accent/60 transition-colors resize-none mb-3 font-sans"
              />
              <button
                onClick={handleDiagnose}
                disabled={diagLoading || !diagAnswer.trim()}
                className="btn-primary disabled:opacity-40"
              >
                {diagLoading ? 'Analyzing...' : '▶ Execute Diagnostic'}
              </button>

              {diagnosticOutput && (
                <div className="mt-4 pt-4 border-t border-border space-y-4">
                  <MarkdownBlock content={diagnosticOutput} />

                  {diagScore !== null && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center justify-between glass p-4 mt-2"
                    >
                      <div>
                        <p className="text-xs text-muted font-mono mb-1">MASTERY SCORE</p>
                        <p className={`text-2xl font-bold font-mono ${
                          diagScore >= 7 ? 'text-green-400'
                          : diagScore >= 4 ? 'text-yellow-400'
                          : 'text-red-400'
                        }`}>
                          {diagScore.toFixed(1)}<span className="text-sm text-muted">/10</span>
                        </p>
                        <p className="text-xs text-muted mt-0.5">
                          {diagScore >= 7 ? 'Strong understanding' : diagScore >= 4 ? 'Needs reinforcement' : 'Flagged for revision'}
                        </p>
                      </div>
                      {!revisionAdded ? (
                        <button
                          onClick={handleAddRevision}
                          className="btn-ghost text-xs flex items-center gap-1.5"
                        >
                          📌 Add to Revision Queue
                        </button>
                      ) : (
                        <span className="tag text-green-400 border-green-800">✓ Queued</span>
                      )}
                    </motion.div>
                  )}
                </div>
              )}
            </Panel>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
