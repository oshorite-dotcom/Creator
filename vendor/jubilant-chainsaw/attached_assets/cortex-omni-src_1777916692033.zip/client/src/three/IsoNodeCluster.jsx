import { useRef, useState, Suspense } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Text } from '@react-three/drei'
import * as THREE from 'three'
import WebGLErrorBoundary from './ErrorBoundary'
import { motion } from 'framer-motion'

const ROLES = [
  { id: 'student',  label: 'Student',  color: '#3b82f6', pos: [-2.2, 0, 0] },
  { id: 'educator', label: 'Educator', color: '#8b5cf6', pos: [2.2,  0, 0] },
  { id: 'parent',   label: 'Parent',   color: '#10b981', pos: [0, 0, 2.2]  },
]

function RoleNode({ role, onSelect, selected }) {
  const meshRef = useRef()
  const [hovered, setHovered] = useState(false)
  const isSelected = selected === role.id

  useFrame((state) => {
    if (!meshRef.current) return
    const t = state.clock.elapsedTime
    meshRef.current.rotation.y = t * 0.4
    const target = isSelected ? 1.35 : hovered ? 1.18 : 1
    meshRef.current.scale.lerp(new THREE.Vector3(target, target, target), 0.1)
  })

  return (
    <group position={role.pos}>
      <mesh
        ref={meshRef}
        onClick={() => onSelect(role.id)}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <icosahedronGeometry args={[0.75, 1]} />
        <meshStandardMaterial
          color={role.color}
          emissive={role.color}
          emissiveIntensity={isSelected ? 0.7 : hovered ? 0.5 : 0.15}
          roughness={0.2}
          metalness={0.8}
        />
      </mesh>
      <Text
        position={[0, -1.15, 0]}
        fontSize={0.28}
        color={role.color}
        anchorX="center"
        anchorY="middle"
      >
        {role.label}
      </Text>
      {(hovered || isSelected) && (
        <mesh>
          <sphereGeometry args={[0.9, 16, 16]} />
          <meshStandardMaterial
            color={role.color}
            transparent
            opacity={0.08}
            side={THREE.BackSide}
          />
        </mesh>
      )}
    </group>
  )
}

function ConnectorLines() {
  const lineRef = useRef()
  useFrame(({ clock }) => {
    if (lineRef.current?.material) {
      lineRef.current.material.opacity =
        0.15 + Math.sin(clock.elapsedTime * 1.5) * 0.08
    }
  })
  const points = ROLES.map(r => new THREE.Vector3(...r.pos))
  points.push(points[0])
  const geometry = new THREE.BufferGeometry().setFromPoints(points)
  return (
    <line ref={lineRef} geometry={geometry}>
      <lineBasicMaterial color="#3b82f6" transparent opacity={0.2} />
    </line>
  )
}

function Scene({ onSelect, selected }) {
  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[5, 5, 5]} intensity={1.5} color="#3b82f6" />
      <pointLight position={[-5, -5, -5]} intensity={0.8} color="#8b5cf6" />
      <ConnectorLines />
      {ROLES.map(role => (
        <RoleNode key={role.id} role={role} onSelect={onSelect} selected={selected} />
      ))}
      <OrbitControls
        enableZoom={false}
        enablePan={false}
        autoRotate
        autoRotateSpeed={0.6}
        maxPolarAngle={Math.PI / 1.8}
        minPolarAngle={Math.PI / 3}
      />
    </>
  )
}

function CSSFallback({ onSelect, selected }) {
  return (
    <div className="flex items-center justify-center gap-6 h-full">
      {ROLES.map(role => (
        <motion.button
          key={role.id}
          onClick={() => onSelect(role.id)}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          className="flex flex-col items-center gap-2"
        >
          <div
            className="w-20 h-20 rounded-2xl flex items-center justify-center text-2xl font-bold border-2 transition-all"
            style={{
              borderColor: selected === role.id ? role.color : '#1e2d45',
              background: selected === role.id
                ? `${role.color}22`
                : 'rgba(255,255,255,0.03)',
              color: role.color,
              boxShadow: selected === role.id ? `0 0 24px ${role.color}55` : 'none',
            }}
          >
            {role.label[0]}
          </div>
          <span className="text-xs font-mono" style={{ color: role.color }}>
            {role.label}
          </span>
        </motion.button>
      ))}
    </div>
  )
}

export default function IsoNodeCluster({ onSelect, selected }) {
  return (
    <WebGLErrorBoundary fallback={<CSSFallback onSelect={onSelect} selected={selected} />}>
      <Canvas
        camera={{ position: [0, 2.5, 7], fov: 50 }}
        style={{ background: 'transparent' }}
        onCreated={({ gl }) => {
          gl.setClearColor(0x000000, 0)
        }}
      >
        <Suspense fallback={null}>
          <Scene onSelect={onSelect} selected={selected} />
        </Suspense>
      </Canvas>
    </WebGLErrorBoundary>
  )
}
