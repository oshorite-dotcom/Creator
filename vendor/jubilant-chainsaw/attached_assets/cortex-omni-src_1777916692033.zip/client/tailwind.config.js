/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        void: '#080c14',
        surface: '#0f1623',
        panel: '#141d2e',
        border: '#1e2d45',
        accent: '#3b82f6',
        glow: '#60a5fa',
        muted: '#4b6280',
        text: '#e2eaf6',
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      backdropBlur: {
        glass: '20px',
      },
      boxShadow: {
        glow: '0 0 40px rgba(59,130,246,0.25)',
        card: '0 4px 32px rgba(0,0,0,0.6)',
      },
    },
  },
  plugins: [],
}
