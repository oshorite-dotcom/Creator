#!/bin/bash
set -e

echo "=== Cortex Omni Build 2.2.0 ==="

# Start FastAPI on port 8000 (background)
echo "[1/2] Starting FastAPI backend on :8000..."
python -m uvicorn server.main:app --host 0.0.0.0 --port 8000 --reload --log-level warning &
FASTAPI_PID=$!
echo "  FastAPI running (pid $FASTAPI_PID)"

# Start Vite dev server on port 5000 (foreground)
echo "[2/2] Starting Vite frontend on :5000..."
cd client && npm run dev

# On exit, kill FastAPI
kill $FASTAPI_PID 2>/dev/null || true
