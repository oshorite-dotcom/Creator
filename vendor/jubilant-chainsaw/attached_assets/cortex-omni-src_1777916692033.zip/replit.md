# Cortex Omni — Build 2.2.0

Adaptive AI Learning Platform | Exam Preparation · Concept Tutoring · Practice · Diagnosis · Persistence

## Architecture

**Full-stack bifurcated spatial app:**
- **Frontend** (`client/`): React 18, Vite, Tailwind CSS, React Three Fiber (R3F), Framer Motion, Zustand
- **Backend** (`server/`): Python, FastAPI, LangGraph, Gemini 2.5 Flash (via langchain-google-genai)
- **Database**: Replit PostgreSQL (psycopg2) — sessions, mastery, revision_queue tables
- **Bridge**: Async REST API, Vite dev proxy (`/api → :8000`)

## Running

`bash start.sh` — starts FastAPI on :8000 (background) + Vite on :5000 (foreground)

Workflow: `Start application` → `bash start.sh` → port 5000 (webview)

## Project Structure

```
server/
├── main.py              # FastAPI app — all /api/* routes, DB startup bootstrap
├── graph/
│   ├── state.py         # AgentState TypedDict
│   └── workflow.py      # LangGraph StateGraph (reasoning → localization)
├── nodes/
│   ├── ingestion.py     # PDF/text/image extraction
│   ├── reasoning.py     # Gemini inference node
│   ├── localization.py  # Hindi translation node
│   ├── diagnostics.py   # Trace-back evaluation (returns score/10)
│   └── practice.py      # Practice question generation
├── services/
│   ├── model_client.py  # ChatGoogleGenerativeAI factory
│   └── db.py            # PostgreSQL persistence layer (sessions, mastery, revision_queue)
└── utils/
    └── config.py        # Constants, RBAC entitlements

client/
├── src/
│   ├── App.jsx                   # Phase router: auth → params → agent → tutor → dashboard
│   ├── store/appStore.js         # Zustand global state (incl. lastQuery)
│   ├── hooks/useAgent.js         # API call hooks (login, invoke, practice, diagnose, revision)
│   ├── components/
│   │   ├── AuthGateway.jsx       # Isometric role selector
│   │   ├── ParameterMatrix.jsx   # Glassmorphic settings panel
│   │   ├── AgentInit.jsx         # Query input + volumetric loading sphere
│   │   ├── TutorInterface.jsx    # Response + practice + diagnostics + mastery score card
│   │   └── Dashboard.jsx         # Session history, mastery scores, revision queue
│   └── three/
│       ├── IsoNodeCluster.jsx    # R3F 3D role node cluster (CSS fallback)
│       ├── PulsingSphere.jsx     # R3F distorted loading sphere (CSS fallback)
│       └── ErrorBoundary.jsx     # WebGL error boundary
```

## Secrets Required

- `GEMINI_API_KEY` — Google AI Studio (https://aistudio.google.com/app/apikey)
- `DATABASE_URL`, `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, `PGDATABASE` — auto-set by Replit PostgreSQL

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/config` | Exam/model/language options |
| POST | `/api/auth/login` | Role-based login (mock JWT) |
| POST | `/api/invoke` | Run LangGraph agent + auto-saves session |
| POST | `/api/ingest` | Upload PDF/text for context |
| POST | `/api/practice` | Generate practice questions |
| POST | `/api/diagnose` | Trace-back diagnostic + auto-updates mastery + queues revision if score < 5 |
| GET | `/api/sessions/{user_id}` | Session history (last 20) |
| GET | `/api/mastery/{user_id}` | Mastery scores by topic |
| POST | `/api/mastery` | Manual mastery update |
| GET | `/api/revision/{user_id}` | Revision queue |
| POST | `/api/revision` | Add topic to revision queue |
| DELETE | `/api/revision/{item_id}` | Dismiss revision item |

## Database Schema

```sql
sessions        — id, user_id, role, exam, query, response, pedagogy, language, created_at
mastery         — id, user_id, topic, exam, score (rolling avg), attempts, last_updated
revision_queue  — id, user_id, topic, exam, difficulty, due_date, created_at
```

## User Flow

1. **Auth Gateway** — Select role node (Student / Educator / Parent) in 3D cluster
2. **Parameter Matrix** — Configure exam, pedagogy style, language, model
3. **Agent Init** — Enter query, optionally attach PDF context, launch agent
4. **Tutor Interface** — Markdown response + practice generator + trace-back diagnostic engine
   - After diagnostic: mastery score card + "Add to Revision Queue" button
   - Sessions auto-saved to PostgreSQL on every invocation
5. **Dashboard** — Session history (clickable to replay), mastery score bars, revision queue

## RBAC

| Role     | Tier | PDF | Diagnostics | Practice |
|----------|------|-----|-------------|----------|
| Student  | Free | ✗   | ✗           | ✓        |
| Student  | Pro  | ✓   | ✓           | ✓        |
| Educator | Any  | ✓   | ✓           | ✓        |
| Parent   | Free | ✗   | ✗           | ✗        |
| Parent   | Pro  | ✗   | ✓           | ✗        |
