from graph.state import AgentState
from nodes.localization import bhashini_localization_layer
from services.model_client import invoke_llm
from utils.config import LANGUAGE_INSTRUCTIONS


def inference_node(state: AgentState) -> AgentState:
    """
    Core LLM generation node.
    Builds exam-aware, pedagogy-styled prompt and routes output through localization layer.
    Fails gracefully — populates final_output with error message rather than crashing.
    """
    try:
        language_instruction = LANGUAGE_INSTRUCTIONS.get(state["language"], "Respond in English.")
        system_prompt = (
            f"Act as an expert tutor for {state['target_exam']}. "
            f"Explanation style: {state['pedagogy_style']}. "
            f"{language_instruction}"
        )
        prompt = (
            f"{system_prompt}\n"
            f"Learner Query: {state['user_input']}\n"
            f"Additional Context: {state['processed_context']}"
        )
        response = invoke_llm(state["model"], prompt)
        state["final_output"] = bhashini_localization_layer(response, state["language"])
    except Exception as e:
        state["final_output"] = (
            f"⚠️ The tutoring engine encountered an issue: {str(e)}. "
            f"Please check your API key or retry."
        )
    return state
