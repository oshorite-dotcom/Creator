import streamlit as st


def show_module_error(context: str, error: Exception) -> None:
    st.warning(f"⚠️ {context} encountered an issue: {str(error)}. Continuing with available output.")


def safe_fallback(value: str, fallback: str = "") -> str:
    return value if value else fallback
