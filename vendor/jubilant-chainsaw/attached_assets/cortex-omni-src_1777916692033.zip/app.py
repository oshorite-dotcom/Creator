"""
Cortex Omni | Build 2.1.0
Zero-Redirect IAM Gateway + Adaptive Educational Orchestration Engine
State-driven, multi-agent, asynchronous learning platform.
"""

import nest_asyncio
nest_asyncio.apply()

import streamlit as st
from graph.state import AgentState
from graph.workflow import cortex_agent
from nodes.ingestion import ingest_multimodal_data
from nodes.tts import generate_segmented_audio
from nodes.diagnostics import trace_back_evaluation
from nodes.practice import generate_practice
from utils.config import AVAILABLE_MODELS, TARGET_EXAMS
from components.auth_ui import render_auth_gateway
from components.dashboard import render_user_header, render_dashboard_panel
from components.three_d import render_exam_scene

st.set_page_config(
    page_title="Cortex Omni",
    layout="wide",
    page_icon="🧠",
    initial_sidebar_state="collapsed",
)

# ── Global dark theme CSS ─────────────────────────────────────────────────────
st.markdown("""
<style>
body, .stApp { background: #121212 !important; color: #FAFAFA; }
section[data-testid="stSidebar"] { background: #181818 !important; }
div[data-testid="stDecoration"] { display: none; }
</style>
""", unsafe_allow_html=True)

# ==========================================
# AUTH GATE — checked before anything else
# ==========================================
if not st.session_state.get("authenticated", False):
    render_auth_gateway()
    st.stop()

# ==========================================
# POST-AUTH: SESSION STATE DEFAULTS
# ==========================================
_defaults = {
    "target_exam": "JEE",
    "pedagogy_style": "Standard",
    "language": "English",
    "model": "gemini-2.5-flash",
    "agent_result": None,
    "practice_output": None,
    "diagnostic_output": None,
    "show_diagnostic": False,
}
for _key, _val in _defaults.items():
    if _key not in st.session_state:
        st.session_state[_key] = _val

# ==========================================
# AUTHENTICATED HEADER
# ==========================================
render_user_header()

# ==========================================
# DASHBOARD PANEL (revision queue + mastery)
# ==========================================
render_dashboard_panel()

st.divider()

# ==========================================
# SIDEBAR — HYPERPARAMETERS
# ==========================================
with st.sidebar:
    st.header("🎛️ Hyperparameters")

    st.session_state.target_exam = st.selectbox(
        "Target Exam / Domain", TARGET_EXAMS,
        index=TARGET_EXAMS.index(st.session_state.target_exam)
    )
    st.session_state.pedagogy_style = st.select_slider(
        "Pedagogy Style", ["Simplified", "Standard", "Abstract"],
        value=st.session_state.pedagogy_style
    )
    st.session_state.language = st.radio(
        "Localization", ["English", "Hindi", "Hinglish"],
        index=["English", "Hindi", "Hinglish"].index(st.session_state.language)
    )

    st.divider()

    st.session_state.model = st.selectbox(
        "AI Model",
        AVAILABLE_MODELS,
        index=AVAILABLE_MODELS.index(st.session_state.model)
    )

    st.divider()

    role = st.session_state.get("user_role", "student")
    st.markdown(f"**Role:** {role.capitalize()}")
    st.markdown(f"**Plan:** {st.session_state.get('subscription_tier','free').capitalize()}")

    st.divider()

    if st.button("🔄 Clear Session", use_container_width=True):
        for key in ["agent_result", "practice_output", "diagnostic_output", "show_diagnostic"]:
            st.session_state[key] = None if key != "show_diagnostic" else False
        st.rerun()

# ==========================================
# MAIN HEADER
# ==========================================
st.title("🧠 Cortex Omni | Build 2.1.0")
st.caption("Adaptive AI Learning Platform — Exam Preparation · Concept Tutoring · Practice · Diagnosis")

# ── 3D Exam Scene (changes live with sidebar selection) ────────────────────
render_exam_scene(st.session_state.get("target_exam", "JEE"), height=220)

st.divider()

# ==========================================
# INPUT LAYER
# ==========================================
uploaded_file = st.file_uploader(
    "📎 Ingest Knowledge Vector (optional)",
    type=["pdf", "png", "txt"],
    help="Upload a PDF, text file, or image to give the agent additional context."
)

user_query = st.text_input(
    "💬 Execute Query:",
    placeholder="Ask anything related to your exam or subject..."
)

if st.button("🚀 Initialize Agent", type="primary", use_container_width=True):
    if not user_query.strip():
        st.warning("Please enter a query before initializing the agent.")
    else:
        context_data = ingest_multimodal_data(
            uploaded_file,
            uploaded_file.type if uploaded_file else "text/plain"
        )

        initial_state = AgentState(
            user_input=user_query,
            target_exam=st.session_state.target_exam,
            pedagogy_style=st.session_state.pedagogy_style,
            language=st.session_state.language,
            model=st.session_state.model,
            processed_context=context_data,
            final_output="",
            trace_back_evaluation="",
            practice_output=""
        )

        with st.spinner("Compiling Agentic Graph..."):
            result = cortex_agent.invoke(initial_state)
            st.session_state.agent_result = result
            st.session_state.practice_output = None
            st.session_state.diagnostic_output = None
            st.session_state.show_diagnostic = False

# ==========================================
# TUTORING RESPONSE OUTPUT
# ==========================================
if st.session_state.agent_result is not None:
    result = st.session_state.agent_result

    st.divider()
    st.subheader("📖 Tutoring Response")
    st.markdown(result["final_output"])

    with st.expander("🔊 Listen to Response (TTS)"):
        if st.button("Generate Audio"):
            with st.spinner("Generating audio..."):
                audio_path = generate_segmented_audio(
                    result["final_output"],
                    st.session_state.language
                )
                if audio_path:
                    st.audio(audio_path)
                else:
                    st.warning("Audio generation failed. Text response is still available.")

    st.divider()

    st.subheader("⚡ What would you like to do next?")
    col1, col2 = st.columns(2)

    with col1:
        if st.button("🎯 Generate Practice Questions", use_container_width=True):
            with st.spinner("Generating practice questions..."):
                st.session_state.practice_output = generate_practice(
                    result["final_output"],
                    st.session_state.target_exam,
                    st.session_state.model,
                    st.session_state.language,
                )

    with col2:
        if st.button("🔍 Diagnose My Answer", use_container_width=True):
            st.session_state.show_diagnostic = True

    if st.session_state.practice_output:
        st.divider()
        st.subheader("🎯 Practice Questions")
        st.markdown(st.session_state.practice_output)

    if st.session_state.show_diagnostic:
        st.divider()
        st.subheader("🔍 Diagnostic Engine (Trace-Back)")
        st.caption("Write your answer or solution process below. The engine will analyze your reasoning path.")

        test_answer = st.text_area(
            "Your Answer / Process:",
            placeholder="Explain how you approached this problem or write your answer here...",
            height=150
        )

        if st.button("▶️ Execute Diagnostic", type="primary"):
            if not test_answer.strip():
                st.warning("Please enter your answer before running diagnostics.")
            else:
                with st.spinner("Analyzing your reasoning path..."):
                    st.session_state.diagnostic_output = trace_back_evaluation(
                        test_answer,
                        result["final_output"],
                        st.session_state.target_exam,
                        st.session_state.model,
                        st.session_state.language,
                    )

        if st.session_state.diagnostic_output:
            st.markdown(st.session_state.diagnostic_output)
