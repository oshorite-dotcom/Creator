import asyncio
import tempfile
import edge_tts


async def _generate_audio_async(text: str, voice: str) -> str:
    communicate = edge_tts.Communicate(text[:500], voice)
    temp_audio = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
    await communicate.save(temp_audio.name)
    return temp_audio.name


def generate_segmented_audio(text: str, language: str = "English") -> str | None:
    """
    Generates TTS audio from text. Returns file path on success, None on failure.
    Failure is isolated — text output is never blocked by TTS issues.
    Voice selection: Hindi/Hinglish -> hi-IN-MadhurNeural, else en-US-GuyNeural.
    """
    try:
        voice = (
            "hi-IN-MadhurNeural"
            if language in ("Hindi", "Hinglish")
            else "en-US-GuyNeural"
        )
        return asyncio.run(_generate_audio_async(text, voice))
    except Exception:
        return None
