"""
Cortex Omni — Legacy Entry Point (Compatibility Shim)

The codebase has been modularized into:
  app.py              -> Streamlit entry point
  graph/state.py      -> AgentState schema
  graph/workflow.py   -> LangGraph compilation
  nodes/              -> ingestion, reasoning, localization, practice, tts, diagnostics
  services/           -> model_client
  utils/              -> config, errors

This file is preserved for compatibility. The workflow now runs app.py directly.
"""

# Redirect execution to app.py
import runpy
runpy.run_path("app.py", run_name="__main__")
