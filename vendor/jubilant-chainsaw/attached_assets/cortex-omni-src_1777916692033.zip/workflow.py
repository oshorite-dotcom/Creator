from langgraph.graph import StateGraph, END
from graph.state import AgentState
from nodes.reasoning import inference_node


def build_workflow():
    """
    Constructs and compiles the Cortex Omni LangGraph workflow.
    Current active nodes: generate (inference)
    Reserved for future nodes: practice, mastery, persistence, diagnostics
    """
    workflow = StateGraph(AgentState)
    workflow.add_node("generate", inference_node)
    workflow.set_entry_point("generate")
    workflow.add_edge("generate", END)
    return workflow.compile()


cortex_agent = build_workflow()
