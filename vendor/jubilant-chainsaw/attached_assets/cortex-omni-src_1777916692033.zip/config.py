AVAILABLE_MODELS = [
    "gemini-2.5-flash",
    "gemini-2.5-pro",
    "gemini-2.0-flash",
    "gemini-2.0-flash-lite",
    "gemini-2.0-flash-001",
    "gemini-2.0-flash-lite-001",
]

TARGET_EXAMS = [
    "JEE",
    "NEET",
    "UPSC",
    "SSC MTS",
    "SSC CHSL",
    "BCECE",
    "B.Sc. Biotechnology",
    "B.Sc. Microbiology",
    "Career/Admission Guidance",
]

LANGUAGE_INSTRUCTIONS = {
    "English": "Respond in English.",
    "Hindi": "Respond entirely in Hindi (Devanagari script).",
    "Hinglish": "Respond in Hinglish — a natural mix of Hindi and English, written in Roman script, as commonly spoken in India.",
}
