from services.model_client import invoke_llm
from utils.config import LANGUAGE_INSTRUCTIONS


def trace_back_evaluation(
    user_answer: str,
    ground_truth: str,
    exam_context: str,
    model: str = "gemini-2.5-flash",
    language: str = "English",
) -> str:
    """
    Trace-Back Diagnostic Engine.
    Evaluates learner reasoning using Chain-of-Thought analysis.
    Does not output Right/Wrong — identifies the exact point of divergence.
    Fails gracefully with a retry message rather than crashing.
    """
    try:
        language_instruction = LANGUAGE_INSTRUCTIONS.get(language, "Respond in English.")
        prompt = f"""
Diagnostic Assessment for {exam_context}.

Ground Truth / Model Answer:
{ground_truth}

Learner Answer / Process:
{user_answer}

Directive:
Do not output 'Right' or 'Wrong'.
Analyze the cognitive path the learner took.
Identify the exact vertex where their logic diverged from the correct reasoning chain.
If their path was correct, confirm optimal execution and explain why it works.
Be specific, constructive, and educationally useful.
{language_instruction}
"""
        return invoke_llm(model, prompt)
    except Exception as e:
        return f"⚠️ Diagnostic engine failed: {str(e)}. Please retry."
