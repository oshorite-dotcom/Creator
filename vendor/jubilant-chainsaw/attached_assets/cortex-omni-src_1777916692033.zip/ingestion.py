import pdfplumber
import streamlit as st
from typing import Any


@st.cache_data(show_spinner=False)
def ingest_multimodal_data(file_buffer: Any, file_type: str) -> str:
    """
    Extracts text from uploaded files.
    Cached via st.cache_data to prevent redundant I/O on UI re-renders.
    Supports PDF and plain text. Images require OCR (not yet integrated).
    Fails gracefully — returns empty string or error note on failure.
    """
    try:
        if file_buffer is None:
            return ""
        if file_type == "application/pdf":
            with pdfplumber.open(file_buffer) as pdf:
                return "\n".join(
                    page.extract_text() or "" for page in pdf.pages
                ).strip()
        elif file_type == "text/plain":
            return file_buffer.read().decode("utf-8")
        elif file_type in ["image/jpeg", "image/png"]:
            return "[Image uploaded — OCR not yet integrated. Describe your image in the query instead.]"
        return ""
    except Exception as e:
        return f"[File extraction failed: {str(e)}. Continuing in text-only mode.]"
