import os

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
DEV_BYPASS_KEY = os.environ.get("DEV_BYPASS_KEY", "")

TARGET_EXAMS = [
    "JEE", "NEET", "UPSC", "CAT", "GATE",
    "SAT", "GRE", "GMAT", "IELTS", "Class 10", "Class 12"
]

AVAILABLE_MODELS = [
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-1.5-pro",
]

PEDAGOGY_STYLES = ["Simplified", "Standard", "Abstract"]
LANGUAGES = ["English", "Hindi", "Hinglish"]

# ── RBAC Entitlement Matrix ───────────────────────────────────────────────────
# query_limit: -1 = unlimited
# Tiers: free | pro | pro_plus | developer

RBAC = {
    "student": {
        "free": {
            "can_use_pdf":             False,
            "can_view_diagnostics":    False,
            "can_use_practice":        True,
            "can_use_advanced_models": False,
            "can_use_hindi":           False,
            "can_use_abstract":        False,
            "can_access_dashboard":    False,
            "can_multi_model":         False,
            "can_export_sessions":     False,
            "can_custom_prompt":       False,
            "can_bulk_pdf":            False,
            "can_dev_panel":           False,
            "query_limit":             5,
        },
        "pro": {
            "can_use_pdf":             True,
            "can_view_diagnostics":    True,
            "can_use_practice":        True,
            "can_use_advanced_models": True,
            "can_use_hindi":           True,
            "can_use_abstract":        True,
            "can_access_dashboard":    True,
            "can_multi_model":         False,
            "can_export_sessions":     False,
            "can_custom_prompt":       False,
            "can_bulk_pdf":            False,
            "can_dev_panel":           False,
            "query_limit":             -1,
        },
        "pro_plus": {
            "can_use_pdf":             True,
            "can_view_diagnostics":    True,
            "can_use_practice":        True,
            "can_use_advanced_models": True,
            "can_use_hindi":           True,
            "can_use_abstract":        True,
            "can_access_dashboard":    True,
            "can_multi_model":         True,
            "can_export_sessions":     True,
            "can_custom_prompt":       True,
            "can_bulk_pdf":            True,
            "can_dev_panel":           False,
            "query_limit":             -1,
        },
    },
    "educator": {
        "free": {
            "can_use_pdf":             True,
            "can_view_diagnostics":    True,
            "can_use_practice":        True,
            "can_use_advanced_models": False,
            "can_use_hindi":           True,
            "can_use_abstract":        True,
            "can_access_dashboard":    True,
            "can_multi_model":         False,
            "can_export_sessions":     False,
            "can_custom_prompt":       False,
            "can_bulk_pdf":            False,
            "can_dev_panel":           False,
            "query_limit":             15,
        },
        "pro": {
            "can_use_pdf":             True,
            "can_view_diagnostics":    True,
            "can_use_practice":        True,
            "can_use_advanced_models": True,
            "can_use_hindi":           True,
            "can_use_abstract":        True,
            "can_access_dashboard":    True,
            "can_multi_model":         False,
            "can_export_sessions":     False,
            "can_custom_prompt":       False,
            "can_bulk_pdf":            False,
            "can_dev_panel":           False,
            "query_limit":             -1,
        },
        "pro_plus": {
            "can_use_pdf":             True,
            "can_view_diagnostics":    True,
            "can_use_practice":        True,
            "can_use_advanced_models": True,
            "can_use_hindi":           True,
            "can_use_abstract":        True,
            "can_access_dashboard":    True,
            "can_multi_model":         True,
            "can_export_sessions":     True,
            "can_custom_prompt":       True,
            "can_bulk_pdf":            True,
            "can_dev_panel":           False,
            "query_limit":             -1,
        },
    },
    "parent": {
        "free": {
            "can_use_pdf":             False,
            "can_view_diagnostics":    False,
            "can_use_practice":        False,
            "can_use_advanced_models": False,
            "can_use_hindi":           False,
            "can_use_abstract":        False,
            "can_access_dashboard":    False,
            "can_multi_model":         False,
            "can_export_sessions":     False,
            "can_custom_prompt":       False,
            "can_bulk_pdf":            False,
            "can_dev_panel":           False,
            "query_limit":             3,
        },
        "pro": {
            "can_use_pdf":             False,
            "can_view_diagnostics":    True,
            "can_use_practice":        False,
            "can_use_advanced_models": False,
            "can_use_hindi":           True,
            "can_use_abstract":        False,
            "can_access_dashboard":    True,
            "can_multi_model":         False,
            "can_export_sessions":     False,
            "can_custom_prompt":       False,
            "can_bulk_pdf":            False,
            "can_dev_panel":           False,
            "query_limit":             10,
        },
        "pro_plus": {
            "can_use_pdf":             False,
            "can_view_diagnostics":    True,
            "can_use_practice":        False,
            "can_use_advanced_models": False,
            "can_use_hindi":           True,
            "can_use_abstract":        False,
            "can_access_dashboard":    True,
            "can_multi_model":         False,
            "can_export_sessions":     True,
            "can_custom_prompt":       False,
            "can_bulk_pdf":            False,
            "can_dev_panel":           False,
            "query_limit":             -1,
        },
    },
    "developer": {
        "developer": {
            "can_use_pdf":             True,
            "can_view_diagnostics":    True,
            "can_use_practice":        True,
            "can_use_advanced_models": True,
            "can_use_hindi":           True,
            "can_use_abstract":        True,
            "can_access_dashboard":    True,
            "can_multi_model":         True,
            "can_export_sessions":     True,
            "can_custom_prompt":       True,
            "can_bulk_pdf":            True,
            "can_dev_panel":           True,
            "query_limit":             -1,
        },
    },
}

DEVELOPER_ENTITLEMENTS = RBAC["developer"]["developer"]


def get_entitlements(role: str, tier: str) -> dict:
    role = role.lower() if role else "student"
    tier = tier.lower() if tier else "free"
    if role == "developer":
        return DEVELOPER_ENTITLEMENTS
    role_map = RBAC.get(role, RBAC["student"])
    return role_map.get(tier, role_map.get("free", RBAC["student"]["free"]))


def verify_dev_key(key: str) -> bool:
    stored = DEV_BYPASS_KEY
    if not stored:
        return False
    return key.strip() == stored.strip()
