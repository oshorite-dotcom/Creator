"""
Cortex Omni — FastAPI Backend
"""
import os
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from server.graph.state import AgentState
from server.graph.workflow import cortex_agent
from server.nodes.ingestion import ingest_multimodal_data
from server.nodes.diagnostics import trace_back_evaluation
from server.nodes.practice import generate_practice
from server.utils.config import get_entitlements, verify_dev_key, DEVELOPER_ENTITLEMENTS, TARGET_EXAMS, AVAILABLE_MODELS, PEDAGOGY_STYLES, LANGUAGES
import server.services.db as db

app = FastAPI(title="Cortex Omni API", version="2.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    try:
        db.bootstrap()
    except Exception as e:
        print(f"[DB] Bootstrap warning: {e}")


# ─── Health & Config ────────────────────────────────────────────────────────

@app.get("/api/health")
def health():
    return {"status": "online", "version": "2.2.0"}


@app.get("/api/config")
def get_config():
    return {
        "target_exams": TARGET_EXAMS,
        "models": AVAILABLE_MODELS,
        "pedagogy_styles": PEDAGOGY_STYLES,
        "languages": LANGUAGES,
    }


# ─── Auth ───────────────────────────────────────────────────────────────────

class AuthRequest(BaseModel):
    role: str
    name: str = "User"
    tier: str = "free"


@app.post("/api/auth/login")
async def login(req: AuthRequest):
    ents = get_entitlements(req.role, req.tier)
    return {
        "token": f"mock-jwt-{req.role}-{req.tier}",
        "user": {
            "name": req.name,
            "role": req.role,
            "tier": req.tier,
            "entitlements": ents,
        }
    }


class DevLoginRequest(BaseModel):
    key: str
    name: str = "Developer"


@app.post("/api/auth/dev-login")
async def dev_login(req: DevLoginRequest):
    if not verify_dev_key(req.key):
        raise HTTPException(status_code=403, detail="Invalid bypass key")
    return {
        "token": "dev-bypass-token",
        "user": {
            "name": req.name,
            "role": "developer",
            "tier": "developer",
            "entitlements": DEVELOPER_ENTITLEMENTS,
        }
    }


# ─── Agent Invocation ────────────────────────────────────────────────────────

class InvokeRequest(BaseModel):
    user_input: str
    target_exam: str = "JEE"
    pedagogy_style: str = "Standard"
    language: str = "English"
    model: str = "gemini-2.5-flash"
    processed_context: str = ""
    role: str = "student"
    tier: str = "free"
    user_id: str = "guest"


@app.post("/api/invoke")
async def invoke_agent(req: InvokeRequest):
    if not req.user_input.strip():
        raise HTTPException(400, "user_input cannot be empty")

    if not os.environ.get("GEMINI_API_KEY"):
        return {
            "final_output": "⚠️ **API Key Missing** — Add your `GEMINI_API_KEY` in the Replit Secrets panel to activate the AI engine.",
            "trace_back_evaluation": "",
            "practice_output": "",
            "session_id": None,
        }

    initial_state: AgentState = {
        "user_input": req.user_input,
        "target_exam": req.target_exam,
        "pedagogy_style": req.pedagogy_style,
        "language": req.language,
        "model": req.model,
        "processed_context": req.processed_context,
        "final_output": "",
        "trace_back_evaluation": "",
        "practice_output": "",
    }

    ents = get_entitlements(req.role, req.tier)

    # Enforce query limit via DB session count (today)
    query_limit = ents.get("query_limit", 5)
    if query_limit > 0:
        try:
            today_sessions = db.get_sessions(req.user_id, limit=query_limit + 1)
            from datetime import datetime, timezone, timedelta
            today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
            today_count = sum(
                1 for s in today_sessions
                if s.get("created_at") and s["created_at"].replace(tzinfo=timezone.utc) >= today_start
            )
            if today_count >= query_limit:
                return {"final_output": "", "trace_back_evaluation": "", "practice_output": "", "session_id": None, "limit_reached": True}
        except Exception:
            pass

    # Enforce model entitlement
    PRO_ONLY_MODELS = ["gemini-1.5-pro"]
    if req.model in PRO_ONLY_MODELS and not ents.get("can_use_advanced_models"):
        req.model = "gemini-2.5-flash"

    result = cortex_agent.invoke(initial_state)
    final = result.get("final_output", "")

    session_id = None
    try:
        session_id = db.save_session(
            user_id=req.user_id,
            role=req.role,
            exam=req.target_exam,
            query=req.user_input,
            response=final,
            pedagogy=req.pedagogy_style,
            language=req.language,
        )
    except Exception as e:
        print(f"[DB] save_session failed: {e}")

    return {
        "final_output": final,
        "trace_back_evaluation": result.get("trace_back_evaluation", ""),
        "practice_output": result.get("practice_output", ""),
        "session_id": session_id,
    }


# ─── Ingest ─────────────────────────────────────────────────────────────────

@app.post("/api/ingest")
async def ingest(file: UploadFile = File(...)):
    content = await file.read()
    extracted = ingest_multimodal_data(content, file.content_type or "text/plain")
    return {"context": extracted}


# ─── Practice ───────────────────────────────────────────────────────────────

class PracticeRequest(BaseModel):
    context: str
    target_exam: str = "JEE"
    model: str = "gemini-2.5-flash"
    language: str = "English"


@app.post("/api/practice")
async def practice(req: PracticeRequest):
    if not os.environ.get("GEMINI_API_KEY"):
        return {"output": "⚠️ API Key Missing."}
    output = generate_practice(req.context, req.target_exam, req.model, req.language)
    return {"output": output}


# ─── Diagnose ───────────────────────────────────────────────────────────────

class DiagnoseRequest(BaseModel):
    student_answer: str
    reference: str
    target_exam: str = "JEE"
    model: str = "gemini-2.5-flash"
    language: str = "English"
    user_id: str = "guest"
    topic: str = ""
    role: str = "student"
    tier: str = "free"


@app.post("/api/diagnose")
async def diagnose(req: DiagnoseRequest):
    ents = get_entitlements(getattr(req, 'role', 'student'), getattr(req, 'tier', 'free'))
    if not ents.get("can_view_diagnostics"):
        raise HTTPException(403, "Diagnostics requires Pro plan")
    if not os.environ.get("GEMINI_API_KEY"):
        return {"output": "⚠️ API Key Missing.", "score": None}

    output = trace_back_evaluation(
        req.student_answer, req.reference,
        req.target_exam, req.model, req.language
    )

    score = None
    mastery_record = None
    try:
        import re
        m = re.search(r'(\d+(?:\.\d+)?)\s*/\s*10', output)
        if m:
            score = float(m.group(1))
            topic = req.topic or req.target_exam
            mastery_record = db.upsert_mastery(req.user_id, topic, req.target_exam, score)
            if score < 5:
                difficulty = "hard" if score < 3 else "medium"
                db.add_to_revision(req.user_id, topic, req.target_exam, difficulty)
    except Exception as e:
        print(f"[DB] mastery upsert failed: {e}")

    return {"output": output, "score": score, "mastery": mastery_record}


# ─── Sessions ───────────────────────────────────────────────────────────────

@app.get("/api/sessions/{user_id}")
def get_sessions(user_id: str, limit: int = 20):
    try:
        sessions = db.get_sessions(user_id, limit)
        return {"sessions": sessions}
    except Exception as e:
        return {"sessions": [], "error": str(e)}


# ─── Mastery ────────────────────────────────────────────────────────────────

@app.get("/api/mastery/{user_id}")
def get_mastery(user_id: str):
    try:
        return {"mastery": db.get_mastery(user_id)}
    except Exception as e:
        return {"mastery": [], "error": str(e)}


class MasteryUpdate(BaseModel):
    topic: str
    exam: str
    score: float
    user_id: str


@app.post("/api/mastery")
def update_mastery(req: MasteryUpdate):
    try:
        record = db.upsert_mastery(req.user_id, req.topic, req.exam, req.score)
        return {"mastery": record}
    except Exception as e:
        raise HTTPException(500, str(e))


# ─── Revision Queue ──────────────────────────────────────────────────────────

@app.get("/api/revision/{user_id}")
def get_revision(user_id: str):
    try:
        return {"queue": db.get_revision_queue(user_id)}
    except Exception as e:
        return {"queue": [], "error": str(e)}


class RevisionAdd(BaseModel):
    user_id: str
    topic: str
    exam: str
    difficulty: str = "medium"


@app.post("/api/revision")
def add_revision(req: RevisionAdd):
    try:
        rid = db.add_to_revision(req.user_id, req.topic, req.exam, req.difficulty)
        return {"id": rid}
    except Exception as e:
        raise HTTPException(500, str(e))


class RevisionDismiss(BaseModel):
    user_id: str


@app.delete("/api/revision/{item_id}")
def dismiss_revision(item_id: str, req: RevisionDismiss):
    try:
        db.remove_from_revision(item_id, req.user_id)
        return {"success": True}
    except Exception as e:
        raise HTTPException(500, str(e))
