from server.services.model_client import get_model

def trace_back_evaluation(student_answer: str, reference: str, exam: str, model_name: str, language: str) -> str:
    model = get_model(model_name)
    lang_note = {"Hindi": "Respond in Hindi.", "Hinglish": "Respond in Hinglish.", "English": "Respond in English."}.get(language, "Respond in English.")

    prompt = f"""You are a diagnostic AI tutor for {exam}.
{lang_note}

**Reference Explanation:**
{reference}

**Student's Answer / Reasoning:**
{student_answer}

Perform a trace-back evaluation:
1. **Conceptual Accuracy** — Identify correct vs incorrect reasoning steps.
2. **Error Taxonomy** — Classify each mistake (conceptual gap, calculation error, incomplete reasoning, etc.).
3. **Root Cause** — Pinpoint the underlying knowledge gap.
4. **Corrective Guidance** — Provide targeted corrections with examples.
5. **Score** — Give a score out of 10 with justification.

Use markdown formatting."""

    result = model.invoke(prompt)
    return result.content
