import io
import base64
from typing import Optional

def ingest_multimodal_data(file_bytes: Optional[bytes], mime_type: str = "text/plain") -> str:
    if not file_bytes:
        return ""
    try:
        if mime_type == "application/pdf" or mime_type.endswith("pdf"):
            import pdfplumber
            with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                return "\n\n".join(
                    page.extract_text() or "" for page in pdf.pages
                ).strip()
        elif mime_type.startswith("text"):
            return file_bytes.decode("utf-8", errors="ignore").strip()
        elif mime_type.startswith("image"):
            return f"[IMAGE_CONTEXT:base64={base64.b64encode(file_bytes).decode()[:64]}...]"
        return ""
    except Exception as e:
        return f"[Ingestion error: {e}]"
