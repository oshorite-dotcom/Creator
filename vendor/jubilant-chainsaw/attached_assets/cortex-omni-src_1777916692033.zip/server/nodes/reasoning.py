from server.graph.state import AgentState
from server.services.model_client import get_model

STYLE_PROMPTS = {
    "Simplified": "Explain in very simple terms with analogies. Avoid jargon.",
    "Standard":   "Provide a thorough, well-structured academic explanation.",
    "Abstract":   "Give a rigorous, mathematically precise, conceptually deep explanation.",
}

LANG_PROMPTS = {
    "English":  "Respond entirely in English.",
    "Hindi":    "पूरी तरह हिंदी में जवाब दें।",
    "Hinglish": "Answer in a natural mix of Hindi and English (Hinglish).",
}

def run_reasoning(state: AgentState) -> AgentState:
    model = get_model(state.get("model", "gemini-2.5-flash"))
    style = STYLE_PROMPTS.get(state.get("pedagogy_style", "Standard"), STYLE_PROMPTS["Standard"])
    lang  = LANG_PROMPTS.get(state.get("language", "English"), LANG_PROMPTS["English"])
    ctx   = state.get("processed_context", "")
    ctx_block = f"\n\n**Supplementary Context:**\n{ctx}" if ctx else ""

    prompt = f"""You are Cortex Omni, an expert AI tutor specializing in {state['target_exam']} preparation.

Pedagogy directive: {style}
Language directive: {lang}
{ctx_block}

Student query: {state['user_input']}

Provide a complete, structured tutoring response. Use markdown formatting with headers, bullet points, and code/math blocks where relevant."""

    response = model.invoke(prompt)
    return {**state, "final_output": response.content}
