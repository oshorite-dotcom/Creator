from server.graph.state import AgentState

def run_localization(state: AgentState) -> AgentState:
    lang = state.get("language", "English")
    output = state.get("final_output", "")

    if lang == "Hindi" and output and not any(
        "\u0900" <= ch <= "\u097f" for ch in output[:50]
    ):
        from server.services.model_client import get_model
        model = get_model(state.get("model", "gemini-2.5-flash"))
        result = model.invoke(f"Translate the following educational content to fluent Hindi:\n\n{output}")
        return {**state, "final_output": result.content}

    return state
