from server.services.model_client import get_model

def generate_practice(context: str, exam: str, model_name: str, language: str) -> str:
    model = get_model(model_name)
    lang_note = {"Hindi": "Write in Hindi.", "Hinglish": "Write in Hinglish.", "English": "Write in English."}.get(language, "Write in English.")

    prompt = f"""You are a {exam} practice question generator.
{lang_note}

Based on the following tutoring content, generate 5 practice problems:
- 2 conceptual MCQs (with 4 options, mark correct answer)
- 2 numerical/application problems (with full solution)
- 1 higher-order thinking question

Content:
{context}

Format each question clearly with labels Q1, Q2... Use markdown."""

    result = model.invoke(prompt)
    return result.content
