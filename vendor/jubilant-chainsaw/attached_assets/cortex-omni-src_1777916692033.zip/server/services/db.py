"""
Cortex Omni — PostgreSQL persistence layer
Tables: sessions, mastery, revision_queue
"""
import os
import uuid
from datetime import datetime, timezone
from contextlib import contextmanager
import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2 import pool as pg_pool

_pool: pg_pool.SimpleConnectionPool | None = None


def _get_pool() -> pg_pool.SimpleConnectionPool:
    global _pool
    if _pool is None:
        _pool = pg_pool.SimpleConnectionPool(
            1, 10,
            dsn=os.environ["DATABASE_URL"],
            cursor_factory=RealDictCursor,
        )
    return _pool


@contextmanager
def cursor():
    conn = _get_pool().getconn()
    try:
        with conn.cursor() as cur:
            yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        _get_pool().putconn(conn)


# ─────────────────────────────────────────────
# Schema bootstrap
# ─────────────────────────────────────────────

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'student',
    exam          TEXT NOT NULL,
    query         TEXT NOT NULL,
    response      TEXT NOT NULL,
    pedagogy      TEXT,
    language      TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS mastery (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       TEXT NOT NULL,
    topic         TEXT NOT NULL,
    exam          TEXT NOT NULL,
    score         FLOAT NOT NULL DEFAULT 0,
    attempts      INT   NOT NULL DEFAULT 1,
    last_updated  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (user_id, topic, exam)
);

CREATE TABLE IF NOT EXISTS revision_queue (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       TEXT NOT NULL,
    topic         TEXT NOT NULL,
    exam          TEXT NOT NULL,
    difficulty    TEXT NOT NULL DEFAULT 'medium',
    due_date      TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sessions_user  ON sessions (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mastery_user   ON mastery  (user_id);
CREATE INDEX IF NOT EXISTS idx_revision_user  ON revision_queue (user_id, due_date);
"""


def bootstrap():
    with cursor() as cur:
        cur.execute(SCHEMA)


# ─────────────────────────────────────────────
# Sessions
# ─────────────────────────────────────────────

def save_session(user_id: str, role: str, exam: str, query: str,
                 response: str, pedagogy: str, language: str) -> str:
    sid = str(uuid.uuid4())
    with cursor() as cur:
        cur.execute(
            """INSERT INTO sessions (id, user_id, role, exam, query, response, pedagogy, language)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
            (sid, user_id, role, exam, query, response, pedagogy, language),
        )
    return sid


def get_sessions(user_id: str, limit: int = 20) -> list[dict]:
    with cursor() as cur:
        cur.execute(
            """SELECT id, exam, query, LEFT(response,120) AS preview,
                      pedagogy, language, created_at
               FROM sessions WHERE user_id=%s
               ORDER BY created_at DESC LIMIT %s""",
            (user_id, limit),
        )
        return [dict(r) for r in cur.fetchall()]


# ─────────────────────────────────────────────
# Mastery
# ─────────────────────────────────────────────

def upsert_mastery(user_id: str, topic: str, exam: str, score: float) -> dict:
    with cursor() as cur:
        cur.execute(
            """INSERT INTO mastery (user_id, topic, exam, score, attempts)
               VALUES (%s,%s,%s,%s,1)
               ON CONFLICT (user_id, topic, exam)
               DO UPDATE SET
                 score        = (mastery.score * mastery.attempts + EXCLUDED.score) / (mastery.attempts + 1),
                 attempts     = mastery.attempts + 1,
                 last_updated = now()
               RETURNING *""",
            (user_id, topic, exam, score),
        )
        return dict(cur.fetchone())


def get_mastery(user_id: str) -> list[dict]:
    with cursor() as cur:
        cur.execute(
            """SELECT topic, exam, score, attempts, last_updated
               FROM mastery WHERE user_id=%s
               ORDER BY last_updated DESC""",
            (user_id,),
        )
        return [dict(r) for r in cur.fetchall()]


# ─────────────────────────────────────────────
# Revision Queue
# ─────────────────────────────────────────────

def add_to_revision(user_id: str, topic: str, exam: str,
                    difficulty: str = "medium") -> str:
    rid = str(uuid.uuid4())
    with cursor() as cur:
        cur.execute(
            """INSERT INTO revision_queue (id, user_id, topic, exam, difficulty)
               VALUES (%s,%s,%s,%s,%s)""",
            (rid, user_id, topic, exam, difficulty),
        )
    return rid


def get_revision_queue(user_id: str) -> list[dict]:
    with cursor() as cur:
        cur.execute(
            """SELECT id, topic, exam, difficulty, due_date
               FROM revision_queue WHERE user_id=%s
               ORDER BY due_date ASC""",
            (user_id,),
        )
        return [dict(r) for r in cur.fetchall()]


def remove_from_revision(item_id: str, user_id: str):
    with cursor() as cur:
        cur.execute(
            "DELETE FROM revision_queue WHERE id=%s AND user_id=%s",
            (item_id, user_id),
        )
