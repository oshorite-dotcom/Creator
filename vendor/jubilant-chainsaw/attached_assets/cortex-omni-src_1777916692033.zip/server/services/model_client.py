import os
from langchain_google_genai import ChatGoogleGenerativeAI

def get_model(model_name: str = "gemini-2.5-flash") -> ChatGoogleGenerativeAI:
    api_key = os.environ.get("GEMINI_API_KEY", "")
    return ChatGoogleGenerativeAI(
        model=model_name,
        google_api_key=api_key,
        temperature=0.7,
    )
