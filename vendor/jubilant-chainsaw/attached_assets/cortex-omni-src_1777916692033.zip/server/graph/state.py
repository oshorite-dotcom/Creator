from typing import TypedDict, Optional

class AgentState(TypedDict):
    user_input: str
    target_exam: str
    pedagogy_style: str
    language: str
    model: str
    processed_context: str
    final_output: str
    trace_back_evaluation: str
    practice_output: str
