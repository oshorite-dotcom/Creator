from langgraph.graph import StateGraph, END
from server.graph.state import AgentState
from server.nodes.reasoning import run_reasoning
from server.nodes.localization import run_localization

def build_graph() -> StateGraph:
    g = StateGraph(AgentState)
    g.add_node("reasoning",    run_reasoning)
    g.add_node("localization", run_localization)
    g.set_entry_point("reasoning")
    g.add_edge("reasoning", "localization")
    g.add_edge("localization", END)
    return g.compile()

cortex_agent = build_graph()
